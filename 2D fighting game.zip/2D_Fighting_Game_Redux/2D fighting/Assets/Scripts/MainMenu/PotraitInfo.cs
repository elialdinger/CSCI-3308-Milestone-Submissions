﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PotraitInfo : MonoBehaviour {

    public int posX;
    public int posY;
    public string characterId;
    public Image img;
}
